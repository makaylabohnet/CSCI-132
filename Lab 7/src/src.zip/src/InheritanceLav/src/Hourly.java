package employeedriver;

public class Hourly {
    private String firstName;
    private String lastName;
    private double wage;
    private int hours;

    public Hourly(String firstName, String lastName, double wage, int hours){
        this.firstName = firstName;
        this.lastName = lastName;
        this.wage= wage;
        this.hours = hours;

    }
}
