package employeedriver;
public class CommissionBase {
    private String firstName;
    private String lastName;
    private double comRate;
    private int grossSales;
    private int base;

    public CommissionBase(String firstName, String lastName, double comRate, int grossSales, int base){
        this.firstName = firstName;
        this.lastName = lastName;
        this.comRate = comRate;
        this.grossSales = grosSales;
        this.base = base;
    }

}
