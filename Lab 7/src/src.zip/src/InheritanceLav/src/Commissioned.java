package employeedriver;
public class Commissioned {
    private String firstName;
    private String lastName;
    private double comRate;
    private int grossSales;

    public Commissioned(String firstName, String lastName, double comRate, int grossSales){
        this.firstName= firstName;
        this.lastName = lastName;
        this.comRate = comRate;
        this.grossSales = grossSales;
    }

}
