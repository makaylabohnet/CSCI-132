package employeedriver;

public class Employee {
    private String firstName;
    private String lastName;
    privat int idNum;

    public Employee(String firstName, String lastName, int idNum){
        this.firstName = firstName;
        this.lastName = lastName;
        this.idNum = idNum;

    }
}
