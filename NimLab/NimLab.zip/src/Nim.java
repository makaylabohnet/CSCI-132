import java.util.Random;

public class Nim {
    //feilds
    private  playerFirst;
    private computerFirst;
    private int n;


    //
    public static int orgStack(){
        Random ran = new Random();
        int upperbound = 100;
        int intRandom = ran.nextInt(100) - 1;
        int intRandom1 = intRandom;
        return intRandom1;

    }
    public static String whoFirst(){
        Random rand = new Random();
        int firstRandom = rand.nextInt(1)-1;

        if (firstRandom == 0){
            return playerFirst;
        }
        if(firstRandom== 1){
            return computerFirst;

        }
        
    }
    public static int stupidOr(){
        int n = orgStack();
        Random rand = new Random();
        int stupidRandom = rand.nextInt(1)-1;
        return stupidRandom;
        if (stupidRandom== 0){
            Random random = new Random();
            int Random = random.nextInt(n/2)-1;
            return stupidRandom;


        }

    }
    public static void main(){
        System.out.println(orgStack());
        System.out.println(whoFirst());
        System.out.println(stupidOr());


}


}

